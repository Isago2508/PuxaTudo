// PuxaTudo — extensão do navegador. Três jeitos de pegar um download, todos automáticos:
//
// 1. CLIQUE NO LINK (clique.js): link para arquivo dos tipos configurados (.zip, .exe...) vai para o
//    PuxaTudo antes de o navegador começar a baixar.
// 2. DIRETO DO LINK, QUALQUER LINK (só Firefox): quando o servidor responde "isto é um download"
//    (Content-Disposition: attachment ou tipo de arquivo binário), a resposta é barrada e o link vai
//    para o PuxaTudo. O Chrome/Edge/Opera não deixam extensão barrar respostas (Manifest V3).
// 3. DO DOWNLOAD DO NAVEGADOR: o que escapar dos dois acima e virar download no navegador é pausado
//    na hora, mandado para o PuxaTudo e, se ele aceitar, CANCELADO e apagado da lista do navegador,
//    para não baixar duas vezes.
//
// Se o PuxaTudo não responder, o navegador baixa normalmente: nada se perde.

// Firefox: "browser.*" devolve promessas ("chrome.*" lá só aceita callback). Chrome/Edge/Opera: "chrome.*" (MV3).
const api = globalThis.browser ?? globalThis.chrome;

const HOST = "com.puxatudo.ponte";
const PADRAO = {
  ativo: true,      // 3. pegar os downloads que o navegador começar
  clique: true,     // 1 e 2. pegar direto no clique do link
  perguntar: true,  // mostrar a janela "Novo download" do PuxaTudo
  minimoKB: 0,      // deixar com o navegador arquivos menores que isto (quando o tamanho é conhecido)
  extensoes: "zip rar 7z gz tgz bz2 xz tar iso img exe msi dmg pkg apk deb rpm jar bin mp4 mkv avi mov wmv flv webm mp3 flac wav m4a",
};

async function config() {
  try {
    return { ...PADRAO, ...(await api.storage.local.get(PADRAO)) };
  } catch {
    return { ...PADRAO };
  }
}

// grava os padrões na primeira vez, para a página (clique.js) já saber os tipos de arquivo
api.runtime.onInstalled.addListener(async () => {
  try { await api.storage.local.set(await config()); } catch {}
});

async function enviar(msg) {
  try {
    const resp = await api.runtime.sendNativeMessage(HOST, msg);
    return resp || { ok: false, erro: "O programa não respondeu." };
  } catch (e) {
    return { ok: false, erro: (e && e.message) || String(e) };
  }
}

async function cookiesDe(url) {
  try {
    const lista = await api.cookies.getAll({ url });
    return (lista || []).map((c) => `${c.name}=${c.value}`).join("; ");
  } catch {
    return "";
  }
}

function nomeDoCaminho(f) {
  const nome = String(f || "").split(/[\\/]/).pop();
  return nome || null;
}

async function marcarProblema(texto) {
  try {
    await api.action.setBadgeBackgroundColor({ color: "#c62828" });
    await api.action.setBadgeText({ text: "!" });
    await api.action.setTitle({ title: "PuxaTudo: " + texto });
  } catch {}
}

async function limparProblema() {
  try {
    await api.action.setBadgeText({ text: "" });
    await api.action.setTitle({ title: "PuxaTudo" });
  } catch {}
}

async function mandarParaPrograma({ url, referer, nome, perguntar }) {
  const resp = await enviar({
    tipo: "baixar",
    url,
    cookies: await cookiesDe(url),
    referer: referer || "",
    nome: nome || null,
    perguntar,
  });
  if (resp.ok) await limparProblema();
  else await marcarProblema("não consegui falar com o programa (" + resp.erro + ")");
  return resp;
}

// Links que o PuxaTudo não aceitou e foram devolvidos ao navegador: não pegar de novo.
const devolvidos = new Set();
function devolverAoNavegador(url) {
  devolvidos.add(url);
  setTimeout(() => devolvidos.delete(url), 60000);
}

const ehHttp = (u) => /^https?:\/\//i.test(u || "");

// ---------------------------------------------------------------- 1. clique no link (clique.js)

api.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.tipo !== "clique" || !ehHttp(msg.url)) return;
  (async () => {
    const c = await config();
    const resp = await mandarParaPrograma({ url: msg.url, referer: msg.referer, nome: msg.nome, perguntar: c.perguntar });
    if (!resp.ok) {
      // o PuxaTudo não respondeu: o navegador baixa, como se a extensão não existisse
      devolverAoNavegador(msg.url);
      try { await api.downloads.download({ url: msg.url }); } catch {}
    }
  })();
});

// ---------------------------------------------------------------- 2. direto do link (Firefox)

const TIPOS_DOWNLOAD = /^(application\/(octet-stream|x-msdownload|x-msdos-program|x-msi|x-ms-installer|zip|x-zip|x-zip-compressed|x-7z-compressed|x-rar|x-rar-compressed|vnd\.rar|gzip|x-gzip|x-tar|x-bzip2|x-xz|x-iso9660-image|x-apple-diskimage|vnd\.android\.package-archive|java-archive|x-debian-package|x-redhat-package-manager|x-bittorrent))\b/i;

function cabecalho(d, nome) {
  const h = (d.responseHeaders || []).find((x) => x.name.toLowerCase() === nome);
  return h ? h.value || "" : "";
}

function nomeDoContentDisposition(v) {
  let m = /filename\*\s*=\s*[^']*'[^']*'([^;]+)/i.exec(v);
  if (m) { try { return decodeURIComponent(m[1].trim().replace(/^"|"$/g, "")); } catch {} }
  m = /filename\s*=\s*"?([^";]+)"?/i.exec(v);
  return m ? m[1].trim() : null;
}

const podeBarrar = (() => {
  try {
    const m = api.runtime.getManifest();
    return (m.permissions || []).includes("webRequestBlocking") && !!api.webRequest;
  } catch { return false; }
})();

if (podeBarrar) {
  api.webRequest.onHeadersReceived.addListener(async (d) => {
    if (d.method !== "GET" || d.statusCode !== 200 || d.tabId < 0) return {};
    if (devolvidos.has(d.url)) return {};
    const disp = cabecalho(d, "content-disposition");
    const tipo = cabecalho(d, "content-type");
    if (/^\s*inline/i.test(disp)) return {};
    if (!/^\s*attachment/i.test(disp) && !TIPOS_DOWNLOAD.test(tipo)) return {};
    const c = await config();
    if (!c.clique) return {};
    const tamanho = parseInt(cabecalho(d, "content-length"), 10) || 0;
    if (c.minimoKB > 0 && tamanho > 0 && tamanho < c.minimoKB * 1024) return {};

    const resp = await mandarParaPrograma({
      url: d.url,
      referer: d.originUrl || d.documentUrl || "",
      nome: nomeDoContentDisposition(disp),
      perguntar: c.perguntar,
    });
    if (resp.ok) return { cancel: true };
    devolverAoNavegador(d.url);
    return {};
  }, { urls: ["<all_urls>"], types: ["main_frame", "sub_frame"] }, ["blocking", "responseHeaders"]);
}

// ---------------------------------------------------------------- 3. do download do navegador

const emAndamento = new Set();

api.downloads.onCreated.addListener(async (item) => {
  // o link original (não o final): links finais costumam ser assinados e expirar; o PuxaTudo segue
  // os redirecionamentos sozinho e assim consegue renovar o link se o download for retomado depois.
  const url = ehHttp(item.url) ? item.url : item.finalUrl || item.url;
  if (!ehHttp(url)) return; // blob:, data:, file: ficam com o navegador
  if (devolvidos.has(item.url) || devolvidos.has(item.finalUrl)) return;
  if (emAndamento.has(item.id)) return;
  emAndamento.add(item.id);

  // Pausa ANTES de qualquer espera: arquivo pequeno em internet rápida termina em menos de um
  // segundo, e aí o navegador e o PuxaTudo baixariam o mesmo arquivo.
  const pausado = api.downloads.pause(item.id).then(() => true, () => false);
  let devolver = true; // se algo der errado, o navegador continua o download dele
  try {
    const c = await config();
    const pausou = await pausado;
    if (!c.ativo) return;
    const [atual] = await api.downloads.search({ id: item.id });
    // Já terminou, ou foi cancelado por você, no navegador: deixa como está.
    // (Pausado pela extensão aparece como "in_progress" no Chrome; no Firefox como "interrupted",
    // às vezes até com erro USER_CANCELED quando nenhum byte tinha chegado.)
    // Se a pausa falhou, o navegador já terminou (ou está terminando): mandar para o PuxaTudo
    // daria arquivo duplicado, então fica com o navegador.
    // Idem se todos os bytes já chegaram (arquivo pequeno ou internet muito rápida): baixar de
    // novo não ganha nada.
    const jaRecebido = atual && atual.totalBytes > 0 && atual.bytesReceived >= atual.totalBytes;
    if (!pausou || !atual || atual.state === "complete" || jaRecebido) {
      // retoma só o que a extensão pausou; se a pausa falhou, pode ter sido você cancelando
      devolver = pausou && !!atual && atual.state !== "complete";
      return;
    }
    const tamanho = atual.totalBytes > 0 ? atual.totalBytes : atual.fileSize;
    if (c.minimoKB > 0 && tamanho > 0 && tamanho < c.minimoKB * 1024) return;

    const resp = await mandarParaPrograma({
      url,
      referer: item.referrer,
      nome: nomeDoCaminho(atual.filename),
      perguntar: c.perguntar,
    });
    if (resp.ok) {
      devolver = false;
      // cancela no navegador e tira da lista dele: o download agora é do PuxaTudo
      try { await api.downloads.cancel(item.id); } catch {}
      try { await api.downloads.erase({ id: item.id }); } catch {}
    }
  } finally {
    if (devolver) { try { await api.downloads.resume(item.id); } catch {} }
    emAndamento.delete(item.id);
  }
});

// ---------------------------------------------------------------- menu do botão direito

async function criarMenus() {
  try {
    await api.contextMenus.removeAll();
    api.contextMenus.create({ id: "puxar-link", title: "Baixar com PuxaTudo", contexts: ["link"] });
    api.contextMenus.create({ id: "puxar-midia", title: "Baixar com PuxaTudo", contexts: ["image", "video", "audio"] });
  } catch { /* menu é extra: a captura automática continua funcionando */ }
}
api.runtime.onInstalled.addListener(criarMenus);
api.runtime.onStartup.addListener(criarMenus);

api.contextMenus.onClicked.addListener(async (info, tab) => {
  const url = info.linkUrl || info.srcUrl;
  if (!ehHttp(url)) return;
  await mandarParaPrograma({ url, referer: info.pageUrl || (tab && tab.url) || "", nome: null, perguntar: true });
});
