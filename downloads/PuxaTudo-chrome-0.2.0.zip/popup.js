const api = globalThis.browser ?? globalThis.chrome; // ver background.js
const HOST = "com.puxatudo.ponte";
const PADRAO = {
  ativo: true, clique: true, perguntar: true, minimoKB: 0,
  extensoes: "zip rar 7z gz tgz bz2 xz tar iso img exe msi dmg pkg apk deb rpm jar bin mp4 mkv avi mov wmv flv webm mp3 flac wav m4a",
};

async function enviar(msg) {
  try {
    return (await api.runtime.sendNativeMessage(HOST, msg)) || { ok: false };
  } catch (e) {
    return { ok: false, erro: (e && e.message) || String(e) };
  }
}

function mostrarSituacao(classe, texto) {
  const el = document.getElementById("situacao");
  el.className = "situacao " + classe;
  document.getElementById("situacao-texto").textContent = texto;
}

async function verificar() {
  const r = await enviar({ tipo: "ping" });
  if (!r.ok) {
    mostrarSituacao("erro", "Programa PuxaTudo não encontrado. Instale ou abra o programa uma vez.");
  } else if (r.programaAberto) {
    mostrarSituacao("ok", "Conectado ao PuxaTudo " + (r.versao || ""));
    api.action.setBadgeText({ text: "" });
  } else {
    mostrarSituacao("fechado", "PuxaTudo instalado (ele abre sozinho quando precisar).");
    api.action.setBadgeText({ text: "" });
  }
}

async function carregar() {
  const c = { ...PADRAO, ...(await api.storage.local.get(PADRAO)) };
  for (const chave of ["clique", "ativo", "perguntar"]) {
    const el = document.getElementById(chave);
    el.checked = c[chave];
    el.addEventListener("change", () => api.storage.local.set({ [chave]: el.checked }));
  }
  const minimo = document.getElementById("minimoKB");
  minimo.value = c.minimoKB;
  const tipos = document.getElementById("extensoes");
  tipos.value = c.extensoes;
  tipos.addEventListener("change", () => {
    const limpo = tipos.value.toLowerCase().split(/[\s,;.]+/).filter(Boolean).join(" ");
    tipos.value = limpo || PADRAO.extensoes;
    api.storage.local.set({ extensoes: tipos.value });
  });
  minimo.addEventListener("change", () =>
    api.storage.local.set({ minimoKB: Math.max(0, parseInt(minimo.value, 10) || 0) }));
  document.getElementById("abrir").addEventListener("click", async () => {
    const r = await enviar({ tipo: "abrir" });
    if (r.ok) window.close();
    else mostrarSituacao("erro", "Não consegui abrir o PuxaTudo: " + (r.erro || ""));
  });
}

carregar();
verificar();
