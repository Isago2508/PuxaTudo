// PuxaTudo — roda em cada página. Pega o clique em links de arquivo (pelo tipo, ex.: .zip, .exe)
// ANTES de o navegador começar a baixar e manda o link para o PuxaTudo.
// Segurar Alt (ou Ctrl/Shift) no clique deixa o link com o navegador.
(() => {
  const api = globalThis.browser ?? globalThis.chrome;
  const PADRAO = { clique: true, extensoes: "" };
  let cfg = { ...PADRAO };

  function carregar(c) {
    cfg = { ...cfg, ...c };
    tipos = new Set(String(cfg.extensoes || "").toLowerCase().split(/[\s,;.]+/).filter(Boolean));
  }
  let tipos = new Set();
  try {
    api.storage.local.get(null).then(carregar, () => {});
    api.storage.onChanged.addListener((mud) => {
      const c = {};
      for (const k in mud) c[k] = mud[k].newValue;
      carregar(c);
    });
  } catch { return; }

  function tipoDoArquivo(url) {
    const nome = url.pathname.split("/").pop() || "";
    const ponto = nome.lastIndexOf(".");
    return ponto > 0 ? nome.slice(ponto + 1).toLowerCase() : "";
  }

  window.addEventListener("click", (ev) => {
    if (!cfg.clique || tipos.size === 0) return;
    if (ev.button !== 0 || ev.altKey || ev.ctrlKey || ev.shiftKey || ev.metaKey) return;
    const link = ev.target instanceof Element ? ev.target.closest("a[href]") : null;
    if (!link) return;
    let url;
    try { url = new URL(link.href, location.href); } catch { return; }
    if (url.protocol !== "http:" && url.protocol !== "https:") return;
    if (!tipos.has(tipoDoArquivo(url))) return;

    ev.preventDefault();
    ev.stopImmediatePropagation();
    api.runtime.sendMessage({
      tipo: "clique",
      url: url.href,
      referer: location.href,
      nome: link.getAttribute("download") || null,
    }).catch?.(() => {});
  }, true);
})();
